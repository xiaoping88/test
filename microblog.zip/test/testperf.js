var http = require('http');

var max = 500;


var agentOptions = {
	maxSockets: max
};

var agent = new http.Agent(agentOptions);

var options = {
	host:'localhost',
	port:3000,
	path:'/',
	method:'get',
	agent:agent
};

for (var i = 0; i < max; i++) {
	 clientrequest(i);
}

function clientrequest(i){
	var startT = new Date();
	http.request(options,function(response){
		  var endT = new Date();
			console.log('%d,%d,耗时:%dms',i,response.statusCode,(endT-startT));
	}).end();
}