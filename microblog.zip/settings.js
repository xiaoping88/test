module.exports = {
  cookieSecret: 'socialB2B',
  db: 'socialB2B',
  host: 'localhost',
  port: 3000,
  dbURL:'mongodb://localhost/socialB2B'
};
