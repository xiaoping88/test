﻿var server = require('./server');

server.start();
