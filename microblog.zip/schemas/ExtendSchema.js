var UserSchema = require('../schemas/UserSchema.js');

module.exports = function(){
	UserSchema.add({ sex: 'string'});
};
