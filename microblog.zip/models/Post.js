var mongoose = require('mongoose');
// var PostSchema = require('../schemas/Post.js');

var PostSchema = new mongoose.Schema({
    user: String,
    post: String,
    time: {
        type: Date,
        'default': Date.now
    }
});

var Post = mongoose.model('Post', PostSchema);

module.exports = Post;
