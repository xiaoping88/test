var Post = require('../models/Post');

exports.doPost = function(req, res) {
    var currentUser = req.session.user;
    Post.create({user: currentUser.name,post: req.body.post}, function(err) {
        if (err) {
            req.flash('error', err);
            return res.redirect('/');
        }
        req.flash('success', '发表成功');
        res.redirect('/u/' + currentUser.name);
    });
};